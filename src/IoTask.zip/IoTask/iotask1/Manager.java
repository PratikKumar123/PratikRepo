package iotask1;

public class Manager extends Employee {

	public static void main(String[] args) {
		
		Manager m = new Manager();
		
		m.method1();
		m.method2();
		m.method3();

	}

}
